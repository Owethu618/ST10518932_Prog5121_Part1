/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapp;

/**
 *
 * @author oweth
 */

public class Login {
    
    //Declaring the variables that the user is going to use to store data
    
    String username;
    String password;
    String phoneNumber;
    
    //A Constructor that prepares default values for user data
    public Login() {
        this.username = "";
        this.password = "";
        this. phoneNumber = "";
        
    }
    
    //Returns the username that is stored
    public String getUsername() {
        return username;
    }
    
    //Returns the password that is stored
    public String getPassword(){
        return password;
    }
    
    //Returns the password that is stored of the user
    public String getPhoneNumber(){
        return phoneNumber;
    }
    
    /*Username's validation , username must contain at least about
      <=5 characters within the username
    */
    
    
    public boolean checkUserName(String username){
        return username.contains("_") && username.length() <=5;
    }
    
    //Password validation using for while and boolean , the password must have >=8
    
    public boolean checkPasswordComplexity(String password) {
        //Declaring boolean variables
        
        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecial = false;
        
        /*for while loop and if statements to check if the user's password contains the neccessary features which are,
        it has to have at least 8 characters, must have a capital letter , a number and a special character
        */
        
        for (int i = 0; i < password.length(); i++) {
            char c = password.charAt(i);
            
            if (Character.isUpperCase(c)) {
                hasCapital = true;
            }else if (Character.isDigit(c)) {
                hasNumber = true;
            }else if (!Character.isLetterOrDigit(c)) {
                hasSpecial = true;
            }
        }
        
        return password.length() >=8 && hasCapital && hasNumber && hasSpecial;
    }
    
    /*Cellphone number validation, the cellphone number must have South
      Africa's unique international code for a cellphone number
    */
    
    public boolean checkCellphoneNumber(String phoneNumber) {
        return phoneNumber.startsWith("+27") && phoneNumber.length() <=12;
    }
    
    //Register user
    public String registerUser (String username, String password, String phoneNumber){
        if(!checkUserName(username)){
           return "Username is not correctly entered, please ensure the username correctly, it has to contain an underscore  and must be no more than 5 characters."; 
        }
        
        if(!checkPasswordComplexity(password)){
            return "Password is not correctly entered, it has to consist of at least 8 characters , a number and a special character";
        }
        if (!checkCellphoneNumber(phoneNumber)){ 
            return "Cellphone number is incorrectly entered or does not contain the international code";
        }
        
        //This is to store the user's data
        this.username = username;
        this.password = password;
        this.phoneNumber = phoneNumber;
        
        return "User is successfully registerd";
        
        
        
       //This looks if the login details matches the one that the user used to register with 
    }
    
    //Login User
    public boolean loginUser(String username, String password){
        return this.username.equals(username) && this.password.equals(password);
    }
    
    //Return Login Status
    public String returnLoginStatus(boolean success) {
        if (success) {
            return "Welcome" + username + "it is great to see you again";
        } else {
            return "Username or password is invalid, please try again";
        }
    }
}
