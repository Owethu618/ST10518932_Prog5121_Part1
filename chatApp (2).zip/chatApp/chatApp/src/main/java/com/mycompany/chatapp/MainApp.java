/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapp;

import java.util.Scanner;

/**
 *
 * @author oweth
 */
public class MainApp {
    public static void main(String[] args) {
         //Adding a scanner that allows a user to enter information
         Scanner input = new Scanner(System.in);
         
         //Creating an object for the Login class so that we can enter our methods
         
         Login login = new Login();
         
         //---Registration Section---
         
         //Prompting user to enrer his or her username
         System.out.println("Enter a username");
         String username = input.nextLine();
         
         //Prompting user to enter his or her password
         System.out.println("Enter your password");
         String password = input.nextLine();
         
         //Prompting user to enter his or her cellphone number
         System.out.println("Enter cellphone number, must contain +27");
         String phoneNumber = input.nextLine();
         
         /*Response when the registerUser has been called,
           and store the message it returns
         */
         String response = login.registerUser(username, password, phoneNumber);
         
         //Displaying the registration message
         System.out.println(response);
         
         
         //---Login---
         System.out.println("\n===User Login===");
         
         
         System.out.println("Enter username");
         String loginUsername = input.nextLine();
         
         System.out.println("Enter password");
         String loginPassword = input.nextLine();
         
         //Verifying username and password if it's entered correctly
         boolean loggedIn = login.loginUser(loginUsername, loginPassword);
         
         //Displaying the login message
         String loginMessage = login.returnLoginStatus(loggedIn);
         System.out.println("Login successful");
         
    }
    
}
